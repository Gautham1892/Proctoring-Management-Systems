-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2021 at 09:04 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proctoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(11) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `AdminuserName` varchar(20) NOT NULL,
  `MobileNumber` int(10) NOT NULL,
  `Email` varchar(120) NOT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `AdminuserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(2, 'Admin', 'admin', 1234567890, 'admin@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2021-06-30 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblcandidates`
--

CREATE TABLE `tblcandidates` (
  `id` int(11) NOT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(12) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `GovtIssuedIdNo` varchar(150) DEFAULT NULL,
  `FullAddress` varchar(255) DEFAULT NULL,
  `State` varchar(200) DEFAULT NULL,
  `RegistrationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcandidates`
--

INSERT INTO `tblcandidates` (`id`, `FullName`, `MobileNumber`, `DateOfBirth`, `GovtIssuedIdNo`, `FullAddress`, `State`, `RegistrationDate`) VALUES
(13, 'Gautham', 1234567891, '2021-06-28', '12', 'a', 'CEG', '2021-07-07 05:02:44'),
(14, 'sreyas', 8888888888, '2021-06-28', '23', 're', 'VIT', '2021-07-07 16:13:36'),
(18, 'ken', 8777777777, '2021-05-04', '78', 're', 'MIT', '2021-07-09 05:06:02'),
(19, 'Nab', 5553333333, '2021-01-09', '46', 'yt', 'CEG', '2021-07-09 05:59:43'),
(20, 'dan', 2222222222, '2021-07-21', '47', 'yu', 'CEG', '2021-07-09 06:08:48'),
(21, 'dinesh', 6666666666, '2021-06-28', '789', 'yu', 'CEG', '2021-07-09 06:14:05');

-- --------------------------------------------------------

--
-- Table structure for table `tblproctors`
--

CREATE TABLE `tblproctors` (
  `id` int(11) NOT NULL,
  `EmpID` varchar(100) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(12) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblproctors`
--

INSERT INTO `tblproctors` (`id`, `EmpID`, `FullName`, `MobileNumber`, `RegDate`) VALUES
(10, '123', 'sourav', 987654321, '2021-07-07 07:56:40'),
(11, '567', 'venkat', 5555555555, '2021-07-07 15:54:26');

-- --------------------------------------------------------

--
-- Table structure for table `tblreporttracking`
--

CREATE TABLE `tblreporttracking` (
  `id` int(11) NOT NULL,
  `OrderNumber` bigint(40) DEFAULT NULL,
  `Remark` varchar(255) DEFAULT NULL,
  `Status` varchar(120) DEFAULT NULL,
  `PostingTime` timestamp NULL DEFAULT current_timestamp(),
  `RemarkBy` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreporttracking`
--

INSERT INTO `tblreporttracking` (`id`, `OrderNumber`, `Remark`, `Status`, `PostingTime`, `RemarkBy`) VALUES
(24, 615780317, 'gd', 'Response Received', '2021-07-09 07:28:04', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbltestrecord`
--

CREATE TABLE `tbltestrecord` (
  `id` int(11) NOT NULL,
  `OrderNumber` bigint(14) DEFAULT NULL,
  `MobileNumber` bigint(14) DEFAULT NULL,
  `TestType` varchar(100) DEFAULT NULL,
  `TestTimeSlot` varchar(120) DEFAULT NULL,
  `ReportStatus` varchar(100) DEFAULT NULL,
  `FinalReport` varchar(150) DEFAULT NULL,
  `ReportUploadTime` varchar(200) DEFAULT NULL,
  `RegistrationDate` timestamp NULL DEFAULT current_timestamp(),
  `AssignedtoEmpId` varchar(150) DEFAULT NULL,
  `AssigntoName` varchar(180) DEFAULT NULL,
  `AssignedTime` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltestrecord`
--

INSERT INTO `tbltestrecord` (`id`, `OrderNumber`, `MobileNumber`, `TestType`, `TestTimeSlot`, `ReportStatus`, `FinalReport`, `ReportUploadTime`, `RegistrationDate`, `AssignedtoEmpId`, `AssigntoName`, `AssignedTime`) VALUES
(15, 303437907, 1234567891, 'Objective', '2021-07-08T10:32', 'Sent to Lab', NULL, NULL, '2021-07-07 05:02:44', '567', 'venkat', '09-07-2021 12:45:45 PM'),
(16, 615780317, 8888888888, 'Subjective', '2021-07-23T21:43', 'Response Received', NULL, NULL, '2021-07-07 16:13:36', '123', 'sourav', '09-07-2021 12:52:34 PM'),
(17, 629476926, 4444444443, 'Subjective', '2021-07-30T20:19', NULL, NULL, NULL, '2021-07-08 14:50:05', NULL, NULL, NULL),
(18, 487296320, 8769074536, 'Objective', '2021-11-01T20:25', NULL, NULL, NULL, '2021-07-08 14:56:11', NULL, NULL, NULL),
(19, 243250467, 3333333333, 'Objective', '2021-07-29T10:34', NULL, NULL, NULL, '2021-07-09 05:04:17', NULL, NULL, NULL),
(20, 329871591, 8777777777, 'Subjective', '2021-07-14T10:35', 'Assigned', NULL, NULL, '2021-07-09 05:06:02', '123', 'sourav', '09-07-2021 12:42:36 PM'),
(21, 465065316, 5553333333, 'Objective', '2021-07-26T11:29', NULL, NULL, NULL, '2021-07-09 05:59:43', NULL, NULL, NULL),
(22, 569784625, 2222222222, 'Objective', '2021-08-05T11:38', NULL, NULL, NULL, '2021-07-09 06:08:48', NULL, NULL, NULL),
(23, 939595289, 6666666666, 'Objective', '2021-07-29T11:44', NULL, NULL, NULL, '2021-07-09 06:14:05', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcandidates`
--
ALTER TABLE `tblcandidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblproctors`
--
ALTER TABLE `tblproctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblreporttracking`
--
ALTER TABLE `tblreporttracking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltestrecord`
--
ALTER TABLE `tbltestrecord`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblcandidates`
--
ALTER TABLE `tblcandidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblproctors`
--
ALTER TABLE `tblproctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblreporttracking`
--
ALTER TABLE `tblreporttracking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbltestrecord`
--
ALTER TABLE `tbltestrecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
