<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Examination Management System</title>
  <link href="css/mycommon.css" rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top" class="c2">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="../index.php">Exam-TMS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">

  <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="new-user-testing.php">Testing</a>
          </li>
           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="live-test-updates.php">Live Updates</a>
          </li>

           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="login.php">Admin</a>
          </li>


        </ul>
      </div>
    </div>
  </nav>
  <div class="c1">
  <center><h2 class="c4"> Our Articles</h2>  </center>

  <p class="c5">Online proctoring has surged during the coronavirus pandemic, and so too have concerns about the practice, in which students take exams under the watchful eyes (human or automated) of third-party programs.<br>Of course, concerns about academic dishonesty are what gave rise to online exam proctoring in the first place. And the switch to rapid remote instruction provides new opportunities and motivations to cheat: everyone is away from campus, under considerable stress.<br>According to an April Educause poll, 54 percent of institutions were using online or remote proctoring services, while another 23 percent were considering or planning to use them.</p>
  <center><img src="img/P3.png" width=500px height=400px></center>
<div class="collumn">
  <h2><span class="hd1">New Stresses, New Temptations</span></h2>
  <p >

According to an April Educause poll, 54 percent of institutions were using online or remote proctoring services, while another 23 percent were considering or planning to use them. Even so, over half of the institutions polled said they were concerned about cost, as well as student privacy. Twenty-six percent of institutions said they were using products that didn’t meet their accessibility standards. Respondus was by far the most widely used product. The most popular method of surveillance was active restriction of students’ computers, but most institutions use more than one form.</p></div>
<div class="collumn">
  <h2><span class="hd1">A Level Playing Field</span></h2>
  <p>Sarah Whorley, assistant professor of biology at Daemen College in New York, uses LockDown Browser and Respondus Monitor by Respondus, which are available to her through her campus. The product training session pitch that resonated with her was "keeping everyone on a level playing field."

That said, Whorley took students' concerns into account in various ways: before going “all in,” she polled students about their technology access at home, took screenshots of herself going through the Respondus monitoring process to demonstrate what test behaviors might get flagged and prompt a review by her, and showed them what a final video would look like to help them feel less self-conscious. Indeed, most proctoring programs record students’ test sessions for a given number of days or months, but individual professors are only prompted to review these sessions when something appears out of the ordinary.</p>

</div>
<div class="collumn">
  <h2><span class="hd1">Students' Rights</span></h2>
  <p >
   Concerns outweigh comments about cheating. Complaints range from awkward (a student reported that his professor had contacted him to request that he stop cursing out loud so much during exams so as to appear less suspicious to the proctoring program) to emotional (many report the format heightens their test anxiety) to technical. On the technical side, students cited unsuitable test time slots due to remote proctor availability (one said he had to take a test at 11 p.m.), long wait times for proctors to answer questions before starting exams, incompatibility between personal computers and platforms, and bad internet connections during exams. In most cases, students are only allowed to log in to a test once, so getting booted offline mid-exam is a big deal..</p>
</div>
<div class="collumn">
  <h2><span class="hd1">Integrity and Growth</span></h2>
  <p >
  Scott Foote, chief information security officer at Examity, an online proctoring company, said growth is up 35 percent from what was expected this fiscal quarter. The company has struggled somewhat to keep pace in hiring, vetting and training new proctors in this remote environment; the company's Slack troubleshooting chat channel is busier than usual. Faculty and proctor training is nonnegotiable for the company, however, he said, as they need to know what they’re looking for and what they aren’t.

“There’s always something that happens -- a dog barking or a kid coming into the room,” he said. “But if I’m taking my exam and turning my hand over and over again looking into my palm, that’s an easy tell.” Both proctors and automated programs know to ignore everyday behaviors such as thinking out loud or eye rolling.

Asked how often students cheat, Foote said he didn’t know. Institutions always make the final decision on who has been dishonest after a review of footage and don’t typically report their findings back to the company. </p></div>
<div class="collumn">
  <h2><span class="hd1">What Is Cheating?</span></h2>
  <p >
    Andrew Robinson, instructor of physics at Carleton University in Canada, said he’s heard about cheating via Chegg, but he tried to make it "very difficult" during his recent open-book final exam, which accounts for 30 percent of students’ grades. He has large courses -- up to 400 students each -- but still managed to give every student a different test by creating a deep question bank with randomized variables in calculations.

On cheating, Robinson said, “You can either implement surveillance tech to prevent that, which will inevitably be bypassed eventually, or come up with different assessments.” And even without the final exam, he added, “other course elements assess competence just fine.” Other assessments include five smaller closed-book tests, online assignments and participation scores from clicker use.

Jesse Stommel, senior lecturer in digital studies at the University of Mary Washington and co-founder of the Digital Pedagogy Lab, said “cheating is a pedagogical issue, not a technological one. There are no easy solutions.”</p></div>




</div>