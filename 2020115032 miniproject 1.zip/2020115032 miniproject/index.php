<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Examination Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="Proctor1/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="Proctor1/css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">Exam-TMS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About Us </a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Layout</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="Proctor1/tandc.php">Articles </a>
          </li>
  <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="Proctor1/new-user-testing.php">Testing</a>
          </li>
           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="Proctor1/live-test-updates.php">Partnerships</a>
          </li>

           <li class="nav-item active">
            <a class="nav-link js-scroll-trigger" href="Proctor1/login.php">Admin</a>
          </li>
          


        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-info text-white">
    <div class="container text-center" >
      <h1>Proctoring Systems</h1>
      <p class="lead">Proctored Exam Management System</p>
    </div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>About Us</h2>
          <p class="lead">Mercer | Mettl successfully executed online examinations with proctor monitoring in premier institutes, such as LogostripLogostripIIMs, IITs, The Washington Center, EBZ Business School Germany, Ashoka University, Miami Dade College, The USA, etc.</p>
          <p class="lead">The expeditious transition toward online examinations has established technology as a solution to overcome unforeseen disruptions. However, at Mercer | Mettl, we are continually innovating to enhance the user-friendliness of our solutions. We wanted to ascertain that the shift to online examinations was not a stop-gap arrangement but a more sure-footed transition. </p>
         
        </div>
      </div>
    </div>
  </section>

  <section id="services" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Services</h2>
          <hr />
<p><strong>Robust Candidate Authentication</strong><br />
Photo verification<br/>
ID card verification</p>
             <hr />
<p><strong>Browser Lockdown</strong><br />
The test is launched in lockdown mode, wherein additional tabs are disabled, and navigation is restricted.<br/>
Restricts the candidates from using cut/copy/paste functions during the test.<br/>
Restricts the candidates from using right-clicks and developer tools during the test.<br/>
Attempts to navigate away from the test window are noted in the log report.</p>
          <hr />
<p><strong>Human-Based Proctoring</strong><br />
Live Proctoring wherein invigilators monitor multiple candidates in a single view.<br/>
Record and review proctoring wherein our team of experts review every recorded session.<br/>
One-to-many + One-on-one human-based proctoring.<br/>
Two-way chat supported between candidates & proctors.</p>
        </div>
      </div>
    </div>
  </section>

  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Layout</h2>
  <ul>
            <li>Speech Sense Accurately Identifies Count Of Unique Speakers In The Vicinity</li>
            <li>It Seamlessly Detects Any Other Person Speaking To The Exam Candidate</li>
            <li>It Separates Candidate Audio From Background Noise; You Get No Unwanted Flags</li>
            
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Gautham's Proctoring Systems 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
